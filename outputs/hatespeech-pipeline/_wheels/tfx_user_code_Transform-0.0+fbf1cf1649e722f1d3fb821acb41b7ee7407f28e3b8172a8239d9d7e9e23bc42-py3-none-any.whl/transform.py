import tensorflow as tf

LABEL_KEY = "labels"
FEATURE_KEY = "text"

def preprocessing_fn(inputs):
    print("DEBUG: Data masuk ke Transform:", inputs.keys())  # Melihat kolom yang ada
    
    if FEATURE_KEY not in inputs:
        raise KeyError(f"ERROR: Kolom {FEATURE_KEY} tidak ditemukan! Kolom yang tersedia: {inputs.keys()}")
    
    print(f"DEBUG: Nilai FEATURE_KEY sebelum transformasi: {inputs[FEATURE_KEY]}")
    print(f"DEBUG: Nilai LABEL_KEY sebelum transformasi: {inputs[LABEL_KEY]}")

    outputs = {}
    LABEL_NAME = LABEL_KEY + "_xf"
    FEATURE_NAME = FEATURE_KEY + "_xf"

    outputs[FEATURE_NAME] = tf.strings.lower(inputs[FEATURE_KEY])
    outputs[LABEL_NAME] = tf.cast(inputs[LABEL_KEY], tf.int64)

    return outputs